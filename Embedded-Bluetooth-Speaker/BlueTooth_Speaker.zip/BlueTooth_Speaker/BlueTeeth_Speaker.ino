#include "BluetoothA2DPSink.h"
#include <time.h>

BluetoothA2DPSink a2dp_sink;
#define BUTTON_PIN 21 // GIOP21 pin connected to button
#define BUTTON_PIN2 19 // GIOP19 pin connected to button


int b;
int buttonState=1;
int count=0;
int pp,kk;


void setup() {
  Serial.begin(921600);
    i2s_pin_config_t my_pin_config = {
        .mck_io_num = I2S_PIN_NO_CHANGE,
        .bck_io_num = 27,
        .ws_io_num = 26,
        .data_out_num = 25,
        .data_in_num = I2S_PIN_NO_CHANGE
    };
    a2dp_sink.set_pin_config(my_pin_config);
    a2dp_sink.start("MyMusic");
    pinMode(BUTTON_PIN, INPUT_PULLUP);
    pinMode(BUTTON_PIN2, INPUT_PULLUP);
}

void loop() {
  
  b=buttonState ;
  buttonState=digitalRead(BUTTON_PIN);
  int buttonState2=digitalRead(BUTTON_PIN2);
  time_t lastTime = time(NULL);
  if(buttonState2!=1){
    while(1){
      time_t currentTime = time(NULL);
      buttonState2=digitalRead(BUTTON_PIN2);
      printf("%ld,%ld\n",lastTime,currentTime);
      while(buttonState2!=1){
        buttonState2=digitalRead(BUTTON_PIN2);
      }
      buttonState2=digitalRead(BUTTON_PIN2);
      if(buttonState2!=1){
          a2dp_sink.next();
          break;
      }
      else if(currentTime-lastTime>=2){
          a2dp_sink.previous();
          break;
      }
    }
  }
  while(buttonState2!=1){
        buttonState2=digitalRead(BUTTON_PIN2);
  }

   
  if(buttonState!=b){
    count++;
  }
  if(count%4==0 && count !=0 && kk==0){
    count=4;
    a2dp_sink.play();
    kk=1;
    pp=0;
  }
  if(count%4==2 && pp==0){
    count=2;
    a2dp_sink.pause();
    pp=1;
    kk=0;
  }
  
  
  
}
